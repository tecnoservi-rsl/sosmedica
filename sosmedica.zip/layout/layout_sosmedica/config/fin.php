<?php
if($AREA_R == '0' && $AREA_L == '0'){


echo '';
}else{

	echo '</div></div>';
}

?>

