<?php

//define('AREA_R', '0');//activar esta area valor 0 es desactivada 1 es activada
//define('AREA_L', '1');//activar esta area valor 0 es desactivada 1 es activada

$AREA_L="0";
$AREA_R="0";


//tamaños de las areas valores aceptados del 1 al 12 o en su defecto 'hidden'
define('AREA_L_XS', '12'); 
define('AREA_L_SM', '4');
define('AREA_L_MD', '3');
define('AREA_L_LG', '3');

define('AREA_R_XS', '3');
define('AREA_R_SM', '3');
define('AREA_R_MD', '3');
define('AREA_R_LG', '3');

?>