$(document).ready(function(){

	

$( document ).on( "click", "#alumnos_re", function() {

	location.href=base_url+'registro/regisalum';
});


$( document ).on( "click", "#profesor_re", function() {

	location.href=base_url+'registro/regispro';
});



});