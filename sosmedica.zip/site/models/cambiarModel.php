<?php

class cambiarModel extends Model
{
    public function __construct() {
        parent::__construct();
    }
    


   public function cambiar_clave($nueva, $usuario)
    {
        
        $sql="update usuario set password='" . Hash::getHash('sha1', $nueva, HASH_KEY) ."' where login='".$usuario."'";
         $this->_db->query($sql);
    } 

    public function actualizar_clave($nueva, $login)
    {
        
        $sql="update usuario set password='" . Hash::getHash('sha1', $nueva, HASH_KEY) ."' where login='".$login."'";
        $this->_db->query($sql);
    }

 public function buscar_usuario($clave, $usuario)
    {
        
        
        $sql="select * from usuario where login='".$usuario."' and password='" . Hash::getHash('sha1', $clave, HASH_KEY) ."'";
       

        $datos = $this->_db->query($sql);
                $datos->setFetchMode(PDO::FETCH_ASSOC);

        return $datos->fetch();
    }




}

?>
