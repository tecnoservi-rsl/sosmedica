<?php

class pdfModel extends Model
{
    public function __construct() {
        parent::__construct();
    }
    
   
    
    
		
}

?>
