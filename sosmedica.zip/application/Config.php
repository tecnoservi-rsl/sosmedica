<?php

/*
 * -------------------------------------
 * www.dlancedu.com | Jaisiel Delance
 * framework mvc basico
 * Config.php
 * -------------------------------------
 */


//define('BASE_URL', 'http://localhost/sosmedica/');
//define('BASE_URL', 'http://192.168.0.5/didactico/');
define('BASE_URL', 'http://gratisxd.esy.es/');
define('DEFAULT_CONTROLLER', 'principal');
define('DEFAULT_LAYOUT', 'layout_sosmedica');
define('APP_NAME', 'TECNOSERVI');
define('APP_SLOGAN', 'Venta de equipos medicos');
define('APP_COMPANY', 'SOS MEDICA');
define('APP_TLF', '');
define('APP_EMAIL', '');
define('SESSION_TIME', 1000000);
define('HASH_KEY', '4f6a6d832be79');
define('DB_HOST', 'localhost');
define('DB_USER', 'u974259085_root');
define('DB_PASS', '20574205');
define('DB_NAME', 'u974259085_venta');
define('DB_CHAR', 'utf8');


?>